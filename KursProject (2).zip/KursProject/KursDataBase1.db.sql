BEGIN TRANSACTION;
CREATE TABLE IF NOT EXISTS "Types" (
	"id"	INTEGER,
	"Name"	TEXT NOT NULL,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "Properties" (
	"id"	INTEGER,
	"Name"	TEXT NOT NULL,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "Game" (
	"id"	INTEGER,
	"CpuScore"	INTEGER,
	"GpuScore"	INTEGER,
	"Ram"	INTEGER,
	PRIMARY KEY("id")
);
CREATE TABLE IF NOT EXISTS "Component_Properties" (
	"id"	INTEGER,
	"Property_id"	INTEGER,
	"Component_id"	INTEGER,
	"Value"	TEXT,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("Property_id") REFERENCES "Properties"("id"),
	FOREIGN KEY("Component_id") REFERENCES "Components"("id")
);
CREATE TABLE IF NOT EXISTS "Components" (
	"id"	INTEGER,
	"Name"	TEXT NOT NULL,
	"Type_id"	INTEGER,
	"Price"	INTEGER,
	PRIMARY KEY("id" AUTOINCREMENT),
	FOREIGN KEY("Type_id") REFERENCES "Types"("id")
);
COMMIT;
